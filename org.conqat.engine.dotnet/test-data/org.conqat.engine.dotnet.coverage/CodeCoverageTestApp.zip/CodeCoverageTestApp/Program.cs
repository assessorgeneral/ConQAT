﻿using System;
using Eu.Cqse.Conqat.Engine.MsCoverage.Testdata;

namespace Eu.Cqse.Conqat.Engine.MsCoverage.Testdata.CodeCoverageTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int argument = 1;
            if(args.Length > 0){
                int.TryParse(args[0], out argument);
            }
            Executed(argument);
        }

        private static void Executed(int argument)
        {
            switch (argument)
            {
                case 1: // call TestAppLibrary1
                    TestAppLibrary1.Class1.ExecuteOn1();
                    break;
                case 2: // call TestAppLibrary2
                    TestAppLibrary2.Class1.ExecuteOn2();
                    break;
                case 3: // call both
                    TestAppLibrary1.Class1.ExecuteOn1();
                    TestAppLibrary2.Class1.ExecuteOn2();
                    break;
                default: // do nothing
                    break;
            }
        }
    }
}
