﻿using System;

namespace Eu.Cqse.Conqat.Engine.MsCoverage.Testdata.TestAppLibrary2
{
    public class Class1
    {
        public static void ExecuteOn2()
        {
            Console.Out.WriteLine("This method is executed if the command line argument is 2");
        }

        public static void NeverExecuted()
        {
            Console.Out.WriteLine("This method should not be executed in test runs.");
        }

        public static void NeverExecuted(int a)
        {
            Console.Out.WriteLine("This method should not be executed in test runs.");
        }

    }
}
