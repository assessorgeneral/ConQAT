/*-------------------------------------------------------------------------+
|                                                                          |
| Copyright 2005-2011 the ConQAT Project                                   |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+-------------------------------------------------------------------------*/
package org.conqat.lib.commons.serialization.classes;

import java.io.IOException;

import org.conqat.lib.commons.serialization.SerializationConsistencyException;

/**
 * Base class for fields of primitive type.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 48022 $
 * @ConQAT.Rating YELLOW Hash: 0827382F88A045C46298DDA73706D3E6
 */
public abstract class SerializedPrimitiveFieldBase extends SerializedFieldBase {

	/** Constructor. */
	protected SerializedPrimitiveFieldBase(String name) {
		super(name);
	}

	/**
	 * Ensures that the given value object is of the given type and not null.
	 * Returns the casted type.
	 */
	@SuppressWarnings("unchecked")
	protected <T> T ensureType(Object value, Class<T> type)
			throws SerializationConsistencyException {
		// TODO (MP) Might this method make sense in ReflectionUtils?
		// TODO (BH): Don't think so, as 80% of the code deals with the
		// construction of the (code specific) exception.
		if (!type.isInstance(value)) {
			String actualType = null;
			if (value != null) {
				actualType = value.getClass().getName();
			}
			throw new SerializationConsistencyException(
					"Would have expected type " + type + " for field "
							+ getName() + " but was " + actualType);
		}
		return (T) value;
	}

	/** Factory method for creating a primitive field from its type code. */
	public static SerializedPrimitiveFieldBase fromTypeCode(char typeCode,
			String fieldName) throws IOException {
		// TODO (MP) We're using a factory to create primitive serialized
		// field objects. Is there any benefit from having these as separate
		// classes, or could we make this class non-abstract? The code below
		// would then call constructors like this:
		// new SerializedPrimitiveField(fieldName, typeCode, classForTypeCode);
		// read/writeValue would then also have a switch/case construct.
		// TODO (BH): As discussed, I would prefer to keep it as this, as we can
		// handle the default case better this way (no exceptions in
		// read/write).

		switch (typeCode) {
		case 'B':
			return new SerializedByteField(fieldName);
		case 'C':
			return new SerializedCharField(fieldName);
		case 'D':
			return new SerializedDoubleField(fieldName);
		case 'F':
			return new SerializedFloatField(fieldName);
		case 'I':
			return new SerializedIntField(fieldName);
		case 'J':
			return new SerializedLongField(fieldName);
		case 'S':
			return new SerializedShortField(fieldName);
		case 'Z':
			return new SerializedBooleanField(fieldName);
		default:
			throw new SerializationConsistencyException(
					"Unrecognized type code: " + typeCode);
		}
	}
}
