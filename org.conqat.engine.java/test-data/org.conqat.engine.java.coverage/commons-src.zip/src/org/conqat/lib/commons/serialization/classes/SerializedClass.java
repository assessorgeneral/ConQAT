/*-------------------------------------------------------------------------+
|                                                                          |
| Copyright 2005-2011 the ConQAT Project                                   |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+-------------------------------------------------------------------------*/
package org.conqat.lib.commons.serialization.classes;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectStreamConstants;
import java.util.ArrayList;
import java.util.List;

import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.UnmodifiableList;
import org.conqat.lib.commons.serialization.SerializedEntityParser;
import org.conqat.lib.commons.serialization.SerializedEntityPool;
import org.conqat.lib.commons.serialization.SerializedEntitySerializer;

/**
 * A serialized class.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 48023 $
 * @ConQAT.Rating YELLOW Hash: 90F2595BE409445C5F80071C534555A1
 */
public class SerializedClass extends SerializedClassBase {

	/** Fully qualified class name. */
	private String name;

	/** The serial version uid. */
	private long serialVersionUid;

	/** The class description flags. */
	private byte classDescriptionFlags;

	/** The fields of the class. */
	private List<SerializedFieldBase> fields;

	/** Constructor. */
	public SerializedClass(DataInputStream din, SerializedEntityPool pool,
			SerializedEntityParser parser) throws IOException {
		super(din, pool, parser);
	}

	/** {@inheritDoc} */
	@Override
	protected void parseClass(DataInputStream din, SerializedEntityPool pool,
			SerializedEntityParser parser) throws IOException {
		this.name = din.readUTF();
		this.serialVersionUid = din.readLong();
		this.classDescriptionFlags = din.readByte();

		short fieldCount = din.readShort();
		fields = new ArrayList<>();
		for (int i = 0; i < fieldCount; ++i) {
			fields.add(readFieldDescription(din, parser));
		}
	}

	/** Parses a <code>fieldDesc</code> part of the stream. */
	private SerializedFieldBase readFieldDescription(DataInputStream din,
			SerializedEntityParser parser) throws IOException {
		byte next = din.readByte();
		String fieldName = din.readUTF();

		switch (next) {
		case SerializedArrayField.TYPE_CODE:
			return new SerializedArrayField(fieldName, parser);
		case SerializedObjectField.TYPE_CODE:
			return new SerializedObjectField(fieldName, parser);
		default:
			return SerializedPrimitiveFieldBase.fromTypeCode((char) next,
					fieldName);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void serializeClass(DataOutputStream dos,
			SerializedEntitySerializer serializer) throws IOException {
		dos.writeByte(ObjectStreamConstants.TC_CLASSDESC);

		dos.writeUTF(name);
		dos.writeLong(serialVersionUid);
		dos.writeByte(classDescriptionFlags);

		dos.writeShort(fields.size());
		for (SerializedFieldBase field : fields) {
			field.serialize(dos, serializer);
		}
	}

	/** Returns the name. */
	public String getName() {
		return name;
	}

	/** Sets the name. */
	public void setName(String name) {
		this.name = name;
	}

	/** Returns the serial version. */
	public long getSerialVersionUid() {
		return serialVersionUid;
	}

	/** Sets the serial version uid. */
	public void setSerialVersionUid(long serialVersionUid) {
		this.serialVersionUid = serialVersionUid;
	}

	/** Returns the class description flags. */
	public byte getClassDescriptionFlags() {
		return classDescriptionFlags;
	}

	/** Returns the fields of this class. */
	public UnmodifiableList<SerializedFieldBase> getFields() {
		return CollectionUtils.asUnmodifiable(fields);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return "Plain class " + name;
	}

	/** Returns the field by name (or null if not found). */
	public SerializedFieldBase getField(String name) {
		// we do not use a map to speed up lookup as field names may be changed
		for (SerializedFieldBase field : fields) {
			if (field.getName().equals(name)) {
				return field;
			}
		}
		return null;
	}

	/** Returns whether this is an externalizable class. */
	public boolean isExternalizable() {
		return (classDescriptionFlags & ObjectStreamConstants.SC_EXTERNALIZABLE) != 0;
	}

	/** Returns whether this is a serializable class. */
	public boolean isSerializable() {
		return (classDescriptionFlags & ObjectStreamConstants.SC_SERIALIZABLE) != 0;
	}

	/**
	 * Returns whether this class has a custom write method (only relevant for
	 * serializable).
	 */
	public boolean hasWriteMethod() {
		return (classDescriptionFlags & ObjectStreamConstants.SC_WRITE_METHOD) != 0;
	}

	/**
	 * Returns whether this class stores block data (only relevant for
	 * externalizable).
	 */
	public boolean hasBlockData() {
		return (classDescriptionFlags & ObjectStreamConstants.SC_BLOCK_DATA) != 0;
	}

}
