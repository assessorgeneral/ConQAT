/*-------------------------------------------------------------------------+
|                                                                          |
| Copyright 2005-2011 the ConQAT Project                                   |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+-------------------------------------------------------------------------*/
package org.conqat.lib.commons.io;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.string.StringUtils;

/**
 * A class for parsing CSV based on a provided enumeration containing the column
 * headers. The reader is iterable row by row, and each value can be requested
 * based on the column's enum value.
 * 
 * @author $Author: goeb $
 * @version $Rev: 47943 $
 * @ConQAT.Rating YELLOW Hash: 44649C1AE126B915B22FBC7DA7958C4A
 */
public class ColumnAwareCsvReader<E extends Enum<E>> implements
		Iterable<Map<E, String>> {

	/** The default column separator */
	public static final char DEFAULT_SEPARATOR = ';';

	/** The table rows (without header) */
	private final List<String> lines;
	/** The pattern for separating values within a row */
	private final Pattern columnSeparatorPattern;
	/** The column names in the order of appearance in the header row */
	private final List<E> columns;
	/** The enum class describing the column titles */
	private final Class<E> clazz;

	/** Constructor */
	public ColumnAwareCsvReader(String csvContent, char separator,
			Class<E> clazz) {
		this.clazz = clazz;
		this.columnSeparatorPattern = Pattern
				.compile(String.valueOf(separator));

		this.lines = StringUtils.splitLinesAsList(csvContent);
		CCSMAssert.isTrue(lines.size() > 0, "CSV File is empty!");

		this.columns = extractColums(lines.remove(0));
	}

	/**
	 * Constructor using the default column separator
	 * {@value #DEFAULT_SEPARATOR}
	 */
	public ColumnAwareCsvReader(String csvContent, Class<E> clazz) {
		this(csvContent, DEFAULT_SEPARATOR, clazz);
	}

	/**
	 * Creates a list of column identifiers from the table's header line. The
	 * element order corresponds to the order in the CSV, so that the column
	 * index can be used to match values to column names.
	 */
	private List<E> extractColums(String string) {
		String[] names = columnSeparatorPattern.split(string);
		List<E> result = new ArrayList<>(names.length);
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			try {
				result.add(i, Enum.valueOf(clazz, name));
			} catch (IllegalArgumentException e) {
				throw new AssertionError("Column name unknown: " + name, e);
			}
		}
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public Iterator<Map<E, String>> iterator() {
		return new CsvRowIterator(lines);
	}

	/**
	 * Iterator for table Rows. This iterator is backed by an iterator over the
	 * lines of the raw CSV string, only adapting the return type of the
	 * {@link #next()} method.
	 */
	private class CsvRowIterator implements Iterator<Map<E, String>> {
		/** The iterator over the table lines. */
		private final Iterator<String> lineIterator;

		/** Constructor. */
		public CsvRowIterator(Iterable<String> lines) {
			this.lineIterator = lines.iterator();
		}

		/** {@inheritDoc} */
		@Override
		public boolean hasNext() {
			return lineIterator.hasNext();
		}

		/** {@inheritDoc} */
		@Override
		public Map<E, String> next() {
			String line = lineIterator.next();
			String[] lineItems = columnSeparatorPattern.split(line);

			Map<E, String> result = new EnumMap<>(clazz);
			for (int i = 0; i < columns.size(); i++) {
				result.put(columns.get(i),
						lineItems[i].replace("\"", StringUtils.EMPTY_STRING));
			}
			return result;
		}

		/** {@inheritDoc} */
		@Override
		public void remove() {
			lineIterator.remove();
		}
	}
}
