/*-------------------------------------------------------------------------+
|                                                                          |
| Copyright 2005-2011 the ConQAT Project                                   |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+-------------------------------------------------------------------------*/
package org.conqat.lib.commons.serialization.classes;

import java.io.IOException;

import org.conqat.lib.commons.serialization.SerializedEntityParser;

/**
 * Field for arrays.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 48022 $
 * @ConQAT.Rating YELLOW Hash: 68E3ACEC70DC1EC74445B870C6D954EA
 */
public class SerializedArrayField extends SerializedComplexFieldBase {

	/** The type code for this kind of field. */
	public static final char TYPE_CODE = '[';

	/** Constructor. */
	public SerializedArrayField(String fieldName, SerializedEntityParser parser)
			throws IOException {
		super(fieldName, parser);
	}

	/** {@inheritDoc} */
	@Override
	protected char getTypeCode() {
		return TYPE_CODE;
	}
}
